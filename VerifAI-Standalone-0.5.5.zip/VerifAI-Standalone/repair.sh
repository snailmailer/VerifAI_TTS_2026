#!/bin/sh
# Registers VerifAI copies already loaded in the browsers and restarts the collector.
exec "$(dirname "$0")/setup.sh" --repair
