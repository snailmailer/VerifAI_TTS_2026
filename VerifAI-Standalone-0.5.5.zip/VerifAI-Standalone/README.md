# VerifAI Standalone - 0.5.5

One per-user setup for **Windows, macOS and Linux** covering **Chrome, Edge, Brave and Firefox** (and the collector for Safari).
Nothing is force-installed: you load the extension in each browser once, guided by on-screen pop-ups.

## Architecture (pictures)

| System architecture | JIT redaction & activity flow |
|---|---|
| ![System architecture](docs/architecture.svg) | ![JIT flow](docs/jit-flow.svg) |

| Standalone installation flow | Enterprise deployment flow |
|---|---|
| ![Standalone flow](docs/standalone-flow.svg) | ![Enterprise flow](docs/enterprise-flow.svg) |

*Open the SVG files in any browser if your Markdown viewer does not render images.*

## What VerifAI does on the device

- **Allows** only Copilot (copilot.microsoft.com, copilot.com, m365.cloud.microsoft), Gemini (gemini.google.com) and Perplexity (perplexity.ai).
- **Blocks** every other catalogued AI site (claude.ai, chatgpt.com, deepseek, huggingface, poe, character.ai, ...) at the network layer and shows the VerifAI block page.
- **Redacts PII before it is sent** in the approved chats: names, SIN/SSN, health card and driver's licence numbers, addresses, emails, phone, cards, bank accounts, dates of birth. Only categories and counts are recorded - never the text.
- **Records** every blocked attempt, approved-site visit and redaction with date/time, browser and hostname, pushes it to the local SOC dashboard **instantly (JIT)** and rewrites the day's **JSON + PDF logs**.
- Everything stays on the device: loopback collector on 127.0.0.1:43821, no cloud, no prompt text.

## Before you start

- Node.js 22 or newer (the setup checks and tells you if it is missing):
  - Windows: not needed - the MVP/USB package bundles the runtime. For the Standalone package install Node.js 22 LTS from https://nodejs.org (one click, no admin needed with the per-user installer).
  - macOS: `brew install node` or download the LTS .pkg from https://nodejs.org. If a `runtime/darwin-<arch>/bin/node` folder exists in this package, setup.sh uses it automatically and nothing needs installing.
  - Linux: `sudo apt install nodejs` (Debian/Ubuntu 24.04+), `sudo dnf install nodejs` (Fedora), or the official tarball from https://nodejs.org. If a `runtime/linux-x64/bin/node` folder exists in this package, setup.sh uses it automatically.
- Your normal user account (no administrator / root needed).
- The browsers you want to protect, installed in their standard locations.

## Install - step by step

| OS | Start the setup |
|----|-----------------|
| Windows | double-click **Setup.cmd** |
| macOS   | open Terminal in this folder and run `sh setup.sh` |
| Linux   | open a terminal in this folder and run `sh setup.sh` |

On Windows the setup first tries **automatic installation**: a progress window shows each browser being told,
through its own per-user policy, to install the signed VerifAI package - you watch it happen and can press
**Cancel and undo** at any time. Browsers only accept a non-store package this way on computers that are
domain / Entra / MDM-enrolled (or once VerifAI is published to the stores). On an unmanaged home PC the window
says so plainly, changes nothing, and the setup falls back to the guided steps below for those browsers.
You can also run **Auto-Install-Extension.cmd** on its own later, and **Undo-Auto-Install.cmd** to reverse it.

The setup then walks you through these screens:

1. **Detected browsers** - type the numbers of the browsers to set up, or press Enter for all.
2. **Daily log folder** - press Enter to accept `<home>/VerifAI/EVENT LOGS` or type another folder.
3. **One pop-up per browser** (Chrome, Edge, Brave):
   1. Top-right corner of the Extensions page: switch **Developer mode** ON.
   2. Click **Load unpacked**.
   3. Paste the folder path from the clipboard into the picker's address bar and press Enter
      (`%LOCALAPPDATA%\VerifAI\Extensions\chromium` on Windows, `~/.local/share/VerifAI/Extensions/chromium` on macOS/Linux).
   4. Click **Select Folder**; "VerifAI Approval Gate" appears.
   5. Make sure its switch is ON; click **Allow** if asked.
   6. Back in the setup window press **Enter** - it waits up to 30 s for the browser to save the extension ID.
4. **Firefox pop-up**: **Load Temporary Add-on...** -> paste the manifest path from the clipboard -> **Open** -> Enter.
5. The setup installs the local collector, native bridge and automatic start-up, registers the detected IDs and checks health.
6. **Finish pop-up** - pin the VerifAI icon and run the verification below.

Re-run the same command any time to add a browser or apply a newer version; records are kept.

### If a browser says "Access to the specified native messaging host is forbidden"
That browser's copy of VerifAI was loaded **after** setup registered the IDs (or in a browser you did not select).
Run **Repair-VerifAI.cmd** (Windows) or **`./repair.sh`** (macOS/Linux): it registers every VerifAI copy found in
Chrome, Edge and Brave in a few seconds without opening any browser. Then reload the extension once.

### If a browser says "Manifest file is missing or unreadable"
The folder picker stopped one level too high. Click **Load unpacked** again, paste the clipboard path into the picker's
**address bar**, press Enter, confirm `manifest.json` is visible, then **Select Folder**.

## Verify it works (2 minutes, synthetic data only)

1. Click the **VerifAI** toolbar icon: the SOC dashboard opens, already signed in.
2. Open **gemini.google.com** (or Copilot / Perplexity) and type: `Resident: Alex Example, SIN: 123-456-789`
3. Press Enter once. The text becomes `[REDACTED: NAME], [REDACTED: SOCIAL INSURANCE NUMBER]` and the send is held; press Enter again to send the clean text.
4. The dashboard's **Redacted PII** tab shows the event within a second; the day's `Redacted_PII_Logs_*.json/.pdf` are updated.
5. Open **claude.ai**: the VerifAI block page appears and **AI Activities** shows the blocked attempt.

## Daily logs

`<EVENT LOGS folder>\<yyyy>\<MMM-yyyy>\AI_Activity_Logs_dd-MMM-yyyy.json` and `.pdf`
`<EVENT LOGS folder>\<yyyy>\<MMM-yyyy>\Redacted_PII_Logs_dd-MMM-yyyy.json` and `.pdf`

Example: `EVENT LOGS\2026\Oct-2026\Redacted_PII_Logs_26-Oct-2026.pdf`. One file per type per day; both are rewritten
after every new event, and a new month/year folder is created automatically. Logs written by earlier versions
(`Oct_2026\..._26_Oct_2026.*`) are moved into this layout the first time the collector starts.

## Uninstall

- Windows: `runtime\install-windows.ps1 -Uninstall` (removes start-up entry and bridge registration; records kept).
- macOS: `launchctl bootout gui/$(id -u)/com.verifai.collector`, then delete `~/Library/LaunchAgents/com.verifai.collector.plist` and the `NativeMessagingHosts/com.verifai.bridge.json` files.
- Linux: `systemctl --user disable --now verifai-collector.service`, then delete the unit file and the `com.verifai.bridge.json` files.
- In each browser remove the VerifAI extension from its Extensions page.

## Private windows (Incognito / InPrivate / Private)

Browsers keep every extension out of private windows until the user allows it, and **Chrome, Edge and Brave
offer no policy that can switch this on** (Microsoft: "by design... to protect user privacy"). VerifAI
therefore:

- **Standalone / USB:** after the extension is detected, setup opens the Extensions page and asks you to turn on
  **Allow in Incognito** (Chrome), **Allow in InPrivate** (Edge) or **Allow in Private** (Brave), re-checks for
  30 seconds, and lists each browser's private-window coverage on the finish screen. The dashboard's
  diagnostics line shows *Private windows: covered / NOT covered*. Firefox asks on install ("Run in Private Windows").
- **Enterprise (default):** removes private mode on Chrome/Edge/Brave by policy (`IncognitoModeAvailability` /
  `InPrivateModeAvailability` = 1) and forces VerifAI on in Firefox Private Windows (`private_browsing: true`,
  Firefox 136+ / ESR 128.8+). `distribution.config.json` -> `privateWindows` offers `gate-edge` (Edge 139+ keeps
  InPrivate but opens it only after the user allows VerifAI there) and `allow` (leave private mode unmanaged).
- Events from private windows are recorded with a **(private)** marker next to the browser name in the dashboard,
  CSV/JSON exports and the daily logs.

## Honest limits

- The browser must be told to enable the extension (standalone) or receive a managed policy (enterprise); no installer can switch on an extension silently without one of those.
- Firefox **temporary** add-ons disappear when Firefox closes; a Mozilla-signed add-on (AMO) is needed for a permanent install - the Enterprise package covers that.
- Safari (macOS/iOS) only runs extensions shipped inside a signed App Store app built with your Apple Developer identity.
- On Android only Firefox supports extensions; on iOS only the Safari app does.
- Detection is pattern based (labelled fields and standard formats); it does not guarantee every possible PII phrasing.
- Private windows on Chrome/Edge/Brave are covered only after the user turns on the per-extension toggle (Standalone) or when private mode is removed by policy (Enterprise default); no installer can grant that access itself.

