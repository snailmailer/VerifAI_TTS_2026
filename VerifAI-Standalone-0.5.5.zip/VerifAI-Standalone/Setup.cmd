@echo off
title VerifAI Standalone setup
if exist "%~dp0runtime\node.exe" (set "NODE=%~dp0runtime\node.exe") else (where node >nul 2>nul && (for /f "delims=" %%n in ('where node') do set "NODE=%%n"))
if not defined NODE (echo Node.js 22+ is required. Install the LTS from https://nodejs.org, or use the MVP USB package which bundles it. & pause & exit /b 1)
"%NODE%" "%~dp0setup.js"
pause
