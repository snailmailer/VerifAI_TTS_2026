#!/bin/sh
set -e
here="$(cd "$(dirname "$0")" && pwd)"
os="$(uname -s | tr '[:upper:]' '[:lower:]')"; arch="$(uname -m)"
case "$arch" in x86_64) arch=x64;; aarch64|arm64) arch=arm64;; esac
bundled="$here/runtime/$os-$arch/bin/node"
if [ -x "$bundled" ]; then node_bin="$bundled"
elif command -v node >/dev/null 2>&1; then node_bin="$(command -v node)"
else
  echo "Node.js 22 or newer is required and was not found."
  case "$os" in
    darwin) echo "  Install with:  brew install node     (or the LTS .pkg from https://nodejs.org)";;
    linux)  echo "  Install with:  sudo apt install nodejs   |   sudo dnf install nodejs   |   https://nodejs.org";;
  esac
  echo "  Or copy the official nodejs.org tarball contents to: $here/runtime/$os-$arch/  and re-run."
  exit 1
fi
major="$("$node_bin" -p 'process.versions.node.split(".")[0]')"
if [ "$major" -lt 22 ]; then echo "Node.js 22+ is required (found $("$node_bin" --version) at $node_bin)."; exit 1; fi
exec "$node_bin" "$here/setup.js" "$@"
