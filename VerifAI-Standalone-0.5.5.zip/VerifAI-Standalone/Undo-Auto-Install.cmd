@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0deployment\auto-install-extension.ps1" -PackageRoot "%~dp0." -Undo
pause
