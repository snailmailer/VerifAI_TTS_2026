@echo off
title VerifAI automatic browser-extension install
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0deployment\auto-install-extension.ps1" -PackageRoot "%~dp0."
pause
