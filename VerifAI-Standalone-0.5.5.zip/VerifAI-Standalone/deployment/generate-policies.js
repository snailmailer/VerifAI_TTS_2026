const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

const domains = {
  chrome: "com.google.Chrome",
  edge: "com.microsoft.Edge",
  brave: "com.brave.Browser",
  firefox: "org.mozilla.firefox"
};
const registry = {
  chrome: "Software\\Policies\\Google\\Chrome",
  edge: "Software\\Policies\\Microsoft\\Edge",
  brave: "Software\\Policies\\BraveSoftware\\Brave",
  firefox: "Software\\Policies\\Mozilla\\Firefox"
};

function httpsUrl(value, label) {
  let url;
  try { url = new URL(value); } catch { throw new Error(`${label}: provide a published HTTPS URL.`); }
  if (url.protocol !== "https:" || url.username || url.password || url.hash) {
    throw new Error(`${label}: HTTPS without credentials or fragments is required.`);
  }
  return url.href;
}

// Private-window handling. Chrome/Edge/Brave cannot be told by policy to run an extension in
// Incognito/InPrivate/Private (per-extension user toggle only), so the enterprise default removes
// private mode; Firefox can force the extension on (private_browsing, Firefox 136+ / ESR 128.8+).
const PRIVATE_DEFAULTS = { chromium: "disable", firefox: "force-extension" };
const PRIVATE_CHROMIUM_MODES = ["disable", "gate-edge", "allow"];
const PRIVATE_FIREFOX_MODES = ["force-extension", "disable"];

function privateWindowPolicies(browser, extensionId, privateWindows = {}) {
  const chromium = privateWindows.chromium ?? PRIVATE_DEFAULTS.chromium;
  const firefox = privateWindows.firefox ?? PRIVATE_DEFAULTS.firefox;
  if (!PRIVATE_CHROMIUM_MODES.includes(chromium)) throw new Error(`privateWindows.chromium must be one of ${PRIVATE_CHROMIUM_MODES.join(", ")}.`);
  if (!PRIVATE_FIREFOX_MODES.includes(firefox)) throw new Error(`privateWindows.firefox must be one of ${PRIVATE_FIREFOX_MODES.join(", ")}.`);
  if (browser === "firefox") {
    return { extraPolicies: firefox === "disable" ? { DisablePrivateBrowsing: true } : {}, extensionExtras: firefox === "force-extension" ? { private_browsing: true } : {} };
  }
  if (chromium === "disable") {
    return { extraPolicies: { [browser === "edge" ? "InPrivateModeAvailability" : "IncognitoModeAvailability"]: 1 }, extensionExtras: {} };
  }
  if (chromium === "gate-edge" && browser === "edge") {
    // Edge 139+: InPrivate stays available but opens only once the user has allowed these extensions in InPrivate.
    return { extraPolicies: { MandatoryExtensionsForInPrivateNavigation: [extensionId] }, extensionExtras: {} };
  }
  return { extraPolicies: {}, extensionExtras: {} };
}

function generate(config) {
  const policies = [];
  const missing = [];
  for (const browser of ["chrome", "edge", "brave", "firefox"]) {
    const entry = config[browser];
    if (!entry || (browser === "firefox" ? !entry.signedXpiUrl : !entry.extensionId)) {
      missing.push(browser);
      continue;
    }
    if (browser === "firefox") {
      if (entry.extensionId !== "verifai-approval-gate@example.com") {
        throw new Error("Firefox ID must match the current signed extension manifest.");
      }
    } else if (!/^[a-p]{32}$/.test(entry.extensionId)) {
      throw new Error(`${browser}: invalid Chromium extension ID (32 letters a-p required).`);
    }
    const settings = { installation_mode: "force_installed" };
    if (browser === "firefox") {
      settings.install_url = httpsUrl(entry.signedXpiUrl, `${browser} signed XPI`);
    } else {
      settings.update_url = httpsUrl(entry.updateUrl, `${browser} update URL`);
    }
    const privacy = privateWindowPolicies(browser, entry.extensionId, config.privateWindows);
    Object.assign(settings, privacy.extensionExtras);
    policies.push({
      browser,
      preferenceDomain: domains[browser],
      registryPath: registry[browser],
      extensionId: entry.extensionId,
      settings,
      extraPolicies: privacy.extraPolicies
    });
  }
  return { policies, missing };
}

function xml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;"
  })[char]);
}

function plist(value) {
  if (typeof value === "boolean") return value ? "<true/>" : "<false/>";
  if (typeof value === "number") return `<integer>${value}</integer>`;
  if (Array.isArray(value)) return `<array>${value.map(plist).join("")}</array>`;
  if (value && typeof value === "object") {
    return `<dict>${Object.entries(value).map(([key, item]) => `<key>${xml(key)}</key>${plist(item)}`).join("")}</dict>`;
  }
  return `<string>${xml(value)}</string>`;
}

function mobileconfig(policy) {
  const prefix = `com.verifai.deployment.${policy.browser}`;
  const payload = {
    PayloadType: policy.preferenceDomain,
    PayloadVersion: "1",
    PayloadIdentifier: `${prefix}.settings`,
    PayloadUUID: crypto.randomUUID(),
    PayloadDisplayName: `VerifAI ${policy.browser}`,
    ExtensionSettings: { [policy.extensionId]: policy.settings },
    ...(policy.extraPolicies || {})
  };
  if (policy.browser === "firefox") payload.EnterprisePoliciesEnabled = true;
  const profile = {
    PayloadType: "Configuration",
    PayloadVersion: "1",
    PayloadIdentifier: prefix,
    PayloadUUID: crypto.randomUUID(),
    PayloadDisplayName: `VerifAI - ${policy.browser} managed extension`,
    PayloadScope: "System",
    PayloadContent: [payload]
  };
  // PayloadVersion is an integer in Apple's configuration-profile schema.
  const content = plist(profile).replaceAll("<key>PayloadVersion</key><string>1</string>", "<key>PayloadVersion</key><integer>1</integer>");
  return `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0">${content}</plist>\n`;
}

if (require.main === module) {
  try {
    const configFile = process.argv[2];
    const output = process.argv[3];
    if (!configFile || !output) throw new Error("Usage: node generate-policies.js CONFIG.json OUTPUT_DIRECTORY");
    const result = generate(JSON.parse(fs.readFileSync(configFile, "utf8")));
    if (result.missing.length) {
      throw new Error(`No deployment generated: published package details missing for ${result.missing.join(", ")}.`);
    }
    fs.mkdirSync(output, { recursive: true });
    fs.writeFileSync(path.join(output, "windows-policy-plan.json"), JSON.stringify(result.policies, null, 2));
    for (const policy of result.policies) {
      fs.writeFileSync(path.join(output, `${policy.browser}.mobileconfig`), mobileconfig(policy));
    }
    console.log("Generated Windows policy plan and four Jamf profiles. Safari is a separate signed app deployment; see deployment guide.");
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}

module.exports = { generate, mobileconfig, plist, privateWindowPolicies, PRIVATE_DEFAULTS };
