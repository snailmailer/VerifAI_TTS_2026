const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { execFileSync } = require("node:child_process");

// Per-user Linux bridge + collector, mirroring the macOS installer. System-wide
// force-install policies are applied separately by install-linux.sh as root.

// A runtime shipped inside the package (runtime/<os>-<arch>/bin/node) is copied into the
// private VerifAI folder so the service keeps working after the package/USB is removed.
function installRuntime(packageRoot, data) {
  const current = fs.realpathSync(process.execPath);
  if (!current.startsWith(fs.realpathSync(packageRoot) + path.sep)) return current;
  const runtimeDirectory = path.join(data, "Runtime");
  fs.mkdirSync(runtimeDirectory, { recursive: true, mode: 0o700 });
  const target = path.join(runtimeDirectory, "node");
  const same = fs.existsSync(target) && fs.statSync(target).size === fs.statSync(current).size &&
    fs.readFileSync(target).equals(fs.readFileSync(current));
  if (!same) {
    fs.copyFileSync(current, `${target}.tmp`);
    fs.chmodSync(`${target}.tmp`, 0o700);
    fs.renameSync(`${target}.tmp`, target);
  }
  console.log(`Bundled runtime installed at ${target}; the package folder can be removed afterwards.`);
  return target;
}
async function main() {
  if (process.platform !== "linux" || process.getuid() === 0) {
    throw new Error("Run in the logged-in Linux user's context, not root.");
  }
  const ids = process.argv.slice(2);
  if (ids.some((id) => !/^[a-p]{32}$/.test(id))) throw new Error("Invalid Chromium extension ID.");
  const data = path.join(os.homedir(), ".local", "share", "VerifAI");
  const app = path.join(data, "App");
  const config = path.join(os.homedir(), ".config");
  const unitFile = path.join(config, "systemd", "user", "verifai-collector.service");
  let health;
  try {
    health = await fetch("http://127.0.0.1:43821/api/health", { signal: AbortSignal.timeout(1000) });
  } catch (error) {
    if (error.cause?.code !== "ECONNREFUSED") throw error;
  }
  if (health) {
    // Re-run: only our own user service is stopped so the upgraded collector can take the port.
    if (!fs.existsSync(unitFile)) throw new Error("Port 43821 is in use by another program. Close it and retry.");
    execFileSync("systemctl", ["--user", "stop", "verifai-collector.service"], { stdio: "ignore" });
    console.log("Stopped the existing VerifAI collector for the upgrade; records are kept.");
  }

  // Runtime files live beside deployment/ in the source tree, or under runtime/ in a built package.
  const packageRoot = path.dirname(__dirname);
  const source = ["runtime", "."].map((folder) => path.join(packageRoot, folder))
    .find((folder) => fs.existsSync(path.join(folder, "local-service.js")));
  if (!source) throw new Error(`Package is incomplete: local-service.js not found under ${packageRoot}.`);
  fs.mkdirSync(app, { recursive: true, mode: 0o700 });
  fs.chmodSync(data, 0o700);
  fs.chmodSync(app, 0o700);
  for (const filename of ["local-service.js", "native-host.js", "activity-storage.js", "event-logs.js",
    "ai-policy.js", "redaction-metadata.js", "redaction-dashboard.js", "package.json",
    "dashboard.html", "dashboard.js", "dashboard.css", "VerifAI Logo.png"]) {
    fs.copyFileSync(path.join(source, filename), path.join(app, filename));
  }
  const nodeExecutable = installRuntime(packageRoot, data);
  const host = path.join(app, "native-host");
  const quote = (value) => `'${value.replaceAll("'", "'\\''")}'`;
  fs.writeFileSync(host, `#!/bin/sh\nexec ${quote(nodeExecutable)} ${quote(path.join(app, "native-host.js"))} "$@"\n`, { mode: 0o700 });
  fs.chmodSync(host, 0o700);

  const origins = ids.map((id) => `chrome-extension://${id}/`);
  const firefox = "verifai-approval-gate@example.com";
  const allowedFile = path.join(app, "native-allowed.json");
  const previous = fs.existsSync(allowedFile) ? JSON.parse(fs.readFileSync(allowedFile, "utf8")) : [];
  const allowed = [...new Set([...previous.filter((value) => /^chrome-extension:\/\/[a-p]{32}\/$/.test(value)), ...origins, firefox])];
  const allOrigins = allowed.filter((value) => value !== firefox);
  fs.writeFileSync(allowedFile, JSON.stringify(allowed), { mode: 0o600 });
  if (process.env.VERIFAI_EVENT_LOGS) {
    const { configureEventLogs } = require(path.join(app, "activity-storage.js"));
    fs.chmodSync(configureEventLogs(data, process.env.VERIFAI_EVENT_LOGS), 0o700);
  }
  for (const [browser, folder] of Object.entries({
    chrome: path.join(config, "google-chrome", "NativeMessagingHosts"),
    edge: path.join(config, "microsoft-edge", "NativeMessagingHosts"),
    brave: path.join(config, "BraveSoftware", "Brave-Browser", "NativeMessagingHosts"),
    firefox: path.join(os.homedir(), ".mozilla", "native-messaging-hosts")
  })) {
    if (browser !== "firefox" && allOrigins.length === 0) continue;
    fs.mkdirSync(folder, { recursive: true });
    const manifest = {
      name: "com.verifai.bridge",
      description: "VerifAI authenticated local bridge",
      path: host,
      type: "stdio",
      ...(browser === "firefox" ? { allowed_extensions: [firefox] } : { allowed_origins: allOrigins })
    };
    fs.writeFileSync(path.join(folder, "com.verifai.bridge.json"), JSON.stringify(manifest, null, 2), { mode: 0o600 });
  }

  fs.mkdirSync(path.dirname(unitFile), { recursive: true });
  fs.writeFileSync(unitFile,
    "[Unit]\nDescription=VerifAI local event collector\nAfter=default.target\n\n" +
    `[Service]\nType=simple\nWorkingDirectory=${app}\n` +
    `ExecStart=${nodeExecutable} ${path.join(app, "local-service.js")}\nRestart=on-failure\n\n` +
    "[Install]\nWantedBy=default.target\n", { mode: 0o600 });
  try {
    execFileSync("systemctl", ["--user", "daemon-reload"], { stdio: "inherit" });
    execFileSync("systemctl", ["--user", "enable", "--now", "verifai-collector.service"], { stdio: "inherit" });
  } catch (error) {
    throw new Error(`Could not start the user service (is systemd --user available?): ${error.message}`);
  }

  let healthy = false;
  for (let attempt = 0; attempt < 10; attempt += 1) {
    try {
      const response = await fetch("http://127.0.0.1:43821/api/health", { signal: AbortSignal.timeout(1000) });
      if ((await response.json()).ok === true) { healthy = true; break; }
    } catch (error) {
      if (attempt === 9) throw new Error(`Collector health check failed: ${error.message}.`);
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  if (!healthy) throw new Error("Collector did not become healthy.");
  console.log("Installed Linux per-user native bridge and systemd --user service.");
}

main().catch((error) => { console.error(error.message); process.exitCode = 1; });
