@echo off
title VerifAI repair
echo Registers VerifAI copies already loaded in Chrome, Edge and Brave and restarts the collector. No browser windows are opened.
if exist "%~dp0runtime\node.exe" (set "NODE=%~dp0runtime\node.exe") else (where node >nul 2>nul && (for /f "delims=" %%n in ('where node') do set "NODE=%%n"))
if not defined NODE (echo Node.js 22+ is required. Install the LTS from https://nodejs.org & pause & exit /b 1)
"%NODE%" "%~dp0setup.js" --repair
pause
