# Data Redaction Blueprint: Legal Guidelines and Detection Patterns

## Purpose and limits

VerifAI performs local, pattern-based text replacement in supported AI composers.
Its Redacted PII tab records only timestamp, hostname, browser, category labels,
replacement count and immediate editor-verification result. It never records
the original prompt, matched values, hashes of values, or replacement text.
An editor edit is not proof that provider framework state or network payloads
contain no sensitive data. Attachments, images, voice and native apps are outside
this text-redaction pipeline.

This document is engineering guidance, not legal advice or a compliance
certification. Regex alone cannot guarantee GDPR anonymization, HIPAA
de-identification or PCI DSS compliance.

## Legal and regulatory considerations

### GDPR

Personal data includes direct and indirect identifiers. Pseudonymized data
remains personal data when re-identification is possible. Removing identifiers
does not automatically anonymize a dataset; assess linkability, singling out,
context and remaining attributes. Special-category data requires additional
consideration. Define a lawful basis, notice, minimization and retention policy.

### HIPAA

HIPAA applies to covered entities and business associates in its scope.
Safe Harbor requires removal of the specified identifiers and no actual
knowledge that remaining information can identify an individual. Dates related
to individuals generally retain only year; ages over 89 require special
handling. Geographic rules include limited ZIP-code exceptions. Expert
Determination is a separate permitted approach.

The 18 identifier categories include names; geography smaller than state;
individual-related dates and ages over 89; telephone; fax; email; SSN;
medical-record numbers; health-plan numbers; account numbers;
certificate/license numbers; vehicle identifiers; device identifiers; URLs;
IP addresses; biometrics; full-face images/comparable images; and other unique
identifiers. This prototype does not detect all these categories.

### PCI DSS

Distinguish display masking from protection of stored PANs. Display is normally
limited to the BIN and last four digits unless a documented business need
permits more. Full suppression is the default here. PANs can contain up to 19
digits; Luhn validation reduces false positives but is not proof of a real card.
Sensitive authentication data, including card verification codes and PIN/PIN
blocks, must not be retained after authorization even when encrypted.
Do not log it in redaction records.

## Detection patterns

Patterns below are illustrative, not a claim that all are enabled in VerifAI.
The current enabled categories are DOB, explicitly introduced names/addresses,
email, formatted SSN, labeled bank account, Luhn-valid PAN, and North American
phone numbers. See the runtime redaction core for exact implementation.

| Category | Illustrative JavaScript pattern | Required validation |
|---|---|---|
| PAN | `\b(?:\d[ -]?){13,19}\b` | Boundaries, 13-19 digits and Luhn; fully suppress |
| CVV/CVC | `\b(?:cvv|cvc|security code)\s*[:=]?\s*\d{3,4}\b` with `gi` | Require financial context; never use loose short-digit matching |
| SSN | `\b\d{3}[- ]?\d{2}[- ]?\d{4}\b` | Context and invalid-number checks; avoid generic nine-digit IDs |
| Email | `\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b` with `gi` | Not exhaustive internationalized-email support |
| IPv4 | `\b(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)\b` | 0-255 octets, boundaries and context; IPv6 requires separate parsing |
| ISO date | `\b\d{4}[-/](?:0[1-9]|1[0-2])[-/](?:0[1-9]|[12]\d|3[01])\b` | Real calendar validation and personal-date context; do not blanket-redact operational dates |

## Execution safeguards

1. Detect on a normalized analysis representation only when offsets can be mapped
   safely to the original. Do not indiscriminately decode URL text or rewrite
   whitespace in user prompts.
2. Prefer contextual anchors, boundary checks, category-specific validation and
   representative multilingual test corpora. Labels/patterns are not a language-
   independent named-entity recognition system.
3. Replace before submission, dispatch the editor's supported update event,
   verify the immediate editor value and stop the current submit attempt when
   replacement occurs. If verification fails, warn the user not to send.
4. Log the process, not data. Validate category enums, bounded counts and a
   boolean edit result. Never include matched text in errors or telemetry.
5. Review false positives/negatives for each provider/editor version and language.
   Obtain legal and security review before regulated deployment.

## References

- GDPR: https://eur-lex.europa.eu/eli/reg/2016/679/oj
- HHS de-identification guidance:
  https://www.hhs.gov/hipaa/for-professionals/privacy/special-topics/de-identification/index.html
- PCI DSS standards library: https://www.pcisecuritystandards.org/document_library/
